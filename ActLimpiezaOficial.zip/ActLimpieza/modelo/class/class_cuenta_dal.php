<?php
    include("class_cuenta.php");
    include("class_db.php"); 

    class cuenta_dal extends class_db{
        function __construct(){
            parent::__construct();
        }

        function __destruct(){
            parent::__destruct();
        }

        public function datos_por_usuario($usuario){
            $usuario=$this->db_conn->real_escape_string($usuario);
            $sql="SELECT * FROM cuenta WHERE usuario= $usuario";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_usuario=mysqli_num_rows($result);
            $obj_det=null;
            if($total_usuario==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new cuenta(
                    $renglon["id_cuenta"],
                    $renglon["usuario"],
                    $renglon["contrasena"]);
            }

            return $obj_det;
        }

        public function datos_por_id_cuenta($id_cuenta){
            $id_cuenta=$this->db_conn->real_escape_string($id_cuenta);
            $sql="SELECT * FROM cuenta WHERE id_cuenta= $id_cuenta";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_id_cuenta=mysqli_num_rows($result);
            $obj_det=null;
            if($total_id_cuenta==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new cuenta(
                    $renglon["id_cuenta"],
                    $renglon["usuario"],
                    $renglon["contrasena"]);
            }

            return $obj_det;
        }

        function existe_cuenta($usuario){
            $usuario=$this->db_conn->real_escape_string($usuario);
            $sql = "SELECT count(*) FROM cuenta WHERE usuario = '$usuario'";
            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
echo "$sql";
            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];
echo json_encode($renglon);
            return $cuantos;    
        }
        function buscar_cuenta($usuario){
            $sql = "SELECT * FROM cuenta WHERE usuario = '$usuario'";
            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
            $renglon=mysqli_fetch_array($rs);
            return $renglon;
        }
        
        function buscar_usuario($obj){
            $sql = "SELECT usuario FROM cuenta";
            $sql .= " WHERE id_cuenta = ".$obj->getId_Cuenta();
            
            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }

        function insertar_cuenta($obj){
            
            $sql="INSERT INTO cuenta(";
            $sql.="id_cuenta,";
            $sql.="usuario,";
            $sql.="contrasena)";            
            $sql.=" VALUES (";
            $sql.=$obj->getId_Cuenta().",";    
            $sql.="'".$obj->getUsuario()."',";
            $sql.="'".$obj->getContrasena()."'";
            $sql.=")";

            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $insertado=1;
                }
                else{
                    $insertado=0;
                }
                unset($obj);
            return $insertado;
        }//end function        

        function borra_cuenta($id_cuenta){
            $id_cuenta=$this->db_conn->real_escape_string($id_cuenta);
            $sql="DELETE FROM cuenta WHERE id_cuenta= $id_cuenta";
            //echo $sql;return;
            $this->set_sql($sql);
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $borrado=1;
                }
                else{
                    $borrado=0;
                }

                unset($obj);
                return $borrado;
        }

        function actualiza_cuenta($obj){
            /*
                    echo '<pre>';
                    echo print_r($obj);
                    echo '</pre>';
                    exit;
            */
            $sql = "UPDATE cuenta SET ";
            $sql .= "nombre="."'".$obj->getUsuario()."',";
            $sql .= "contrasena="."'".$obj->getContrasena()."',";
            $sql .= " WHERE id_cuenta = ".$obj->getId_Cuenta();
            
            //echo $sql;//exit;
            
            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
            
            mysqli_query($this->db_conn,$this->db_query) 
            or die(mysqli_error($this->db_conn));
                
                if(mysqli_affected_rows($this->db_conn)==1) {
                    $actualizado=1;
                }            
                else{
                    $actualizado=0;
                }
            unset($obj);
            return $actualizado;
        }
        
    }//end class
?>