<?php
    include("class_actividad.php");
    include("class_db.php");


    class actividad_dal extends class_db{
        function __construct(){
            parent::__construct();
        }

        function __destruct(){
            parent::__destruct();
        }

        public function datos_por_nombre($nombre){
            $nombre=$this->db_conn->real_escape_string($nombre);
            $sql="SELECT * FROM actividad WHERE nombre= $nombre";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_nombre=mysqli_num_rows($result);
            $obj_det=null;
            if($total_nombre==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new actividad(
                    $renglon["id_actividad"],
                    $renglon["id_cuadrilla"],
                    $renglon["id_colonia"],
                    $renglon["nombre"],
                    $renglon["descripcion"],
                    $renglon["estado"],
                    $renglon["imagen"]);
            }

            return $obj_det;
        }

        public function datos_por_id($id_actividad){
            $id_actividad=$this->db_conn->real_escape_string($id_actividad);
            $sql="SELECT * FROM actividad WHERE id_actividad= $id_actividad";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_id_actividad=mysqli_num_rows($result);
            $obj_det=null;
            if($total_id_actividad==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new actividad(
                    $renglon["id_actividad"],
                    $renglon["id_cuadrilla"],
                    $renglon["id_colonia"],
                    $renglon["nombre"],
                    $renglon["descripcion"],
                    $renglon["estado"],
                    $renglon["imagen"]);
                    return  $obj_det;
                }
          
        }

        function existe_actividad_nombre($nombre){
            $nombre=$this->db_conn->real_escape_string($nombre);
            $sql = "SELECT count(*) FROM actividad";
            $sql.=" WHERE nombre= $nombre";

            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }

        function existe_actividad_id($id_actividad){
            $id_actividad=$this->db_conn->real_escape_string($id_actividad);
            $sql = "SELECT count(*) FROM actividad";
            $sql.=" WHERE id_actividad= $id_actividad";

            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }

        function lista_actividad(){
            $sql="SELECT * FROM actividad";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_actividad=mysqli_num_rows($result);
            $obj_det=null;

            if ($total_actividad>0){
                $i=0;
                while($renglon = mysqli_fetch_assoc($result)){
                    $obj_det= new actividad(
                        $renglon["id_actividad"],
                        $renglon["id_cuadrilla"],
                        $renglon["id_colonia"],
                        $renglon["nombre"],
                        $renglon["descripcion"],
                        $renglon["estado"],
                        $renglon["imagen"]);

                        $i++;
                        $lista[$i]=$obj_det;
                        unset($obj_det); 
                }//end while
                return $lista;
            }
        }

        function insertar_actividad($obj){
            
            $sql="INSERT INTO actividad(";
            $sql.="id_actividad,";
            $sql.="id_cuadrilla,";
            $sql.="id_colonia,";
            $sql.="nombre,";
            $sql.="descripcion,";
            $sql.="estado,";
            $sql.="imagen)";         
            $sql.=" VALUES (";
            $sql.=$obj->getId_Actividad().",";    
            $sql.=$obj->getId_Cuadrilla().",";
            $sql.=$obj->getId_Colonia().",";
            $sql.="'".$obj->getNombre()."',";
            $sql.="'".$obj->getDescripcion()."',";
            $sql.= "'".$obj->getEstado()."',";
            $sql.= "'".$obj->getImagen()."'";
            $sql.=")";

            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $insertado=1;
                }
                else{
                    $insertado=0;
                }
                unset($obj);
                return $insertado;
        }//end function        

        function borra_actividad($id_actividad){
            $id_actividad=$this->db_conn->real_escape_string($id_actividad);
            $sql="DELETE FROM actividad WHERE id_actividad= $id_actividad";
            //echo $sql;return;
            $this->set_sql($sql);
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $borrado=1;
                }
                else{
                    $borrado=0;
                }

                unset($obj);
                return $borrado;
        }

        function actualiza_actividad($obj){
            /*
                    echo '<pre>';
                    echo print_r($obj);
                    echo '</pre>';
                    exit;
            */
            $sql = "UPDATE actividad SET ";
            $sql .= "nombre = ".$obj->getId_Cuadrilla().",";
            $sql .= "apellido = ".$obj->getId_Colonia().",";
            $sql .= "tipoUsuario = "."'".$obj->getNombre()."',";                
            $sql .= "correo = "."'".$obj->getDescripcion()."',";
            $sql .= "telefono = "."'".$obj->getEstado()."',";
            $sql .= "nombre = "."'".$obj->getImagen()."'";
            $sql .= " WHERE id_actividad = ".$obj->getId_Actividad();

            //echo $sql;//exit;
            
            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
                    
            mysqli_query($this->db_conn,$this->db_query) 
            or die(mysqli_error($this->db_conn));         
            
                if(mysqli_affected_rows($this->db_conn)==1) {
                    $actualizado=1;
                }
                else{
                    $actualizado=0;
                }
            unset($obj);
            return $actualizado;
        }

    }//end class
?>