<?php
if (class_exists("actividad")!=true){
    class actividad{
        protected $id_actividad;
        protected $id_cuadrilla;
        protected $id_colonia;
        protected $nombre;
        protected $descripcion;
        protected $estado;
        protected $imagen;

        public function __construct(
            $id_actividad=NULL,
            $id_cuadrilla=NULL,
            $id_colonia=NULL,
            $nombre=NULL,
            $descripcion=NULL,
            $estado=NULL,
            $imagen=NULL) {
                $this->id_actividad=$id_actividad;
                $this->id_cuadrilla=$id_cuadrilla;
                $this->id_colonia=$id_colonia;
                $this->nombre=$nombre;
                $this->descripcion=$descripcion;
                $this->estado=$estado;
                $this->imagen=$imagen;
        }
        
        public function getId_Actividad() {
            return $this->id_actividad;
        }

        public function setId_Actividad($id_actividad) {
                $this->id_actividad = $id_actividad;
                return $this;
        }

        public function getId_Cuadrilla() {
            return $this->id_cuadrilla;
        }

        public function setId_Cuadrilla($id_cuadrilla) {
                $this->id_cuadrilla = $id_cuadrilla;
                return $this;
        }

        public function getId_Colonia() {
                return $this->id_colonia;
        }

        public function setId_Colonia($id_colonia) {
                $this->id_colonia = $id_colonia;
                return $this;
        }

        public function getNombre() {
                return $this->nombre;
        }

        public function setNombre($nombre) {
                $this->nombre = $nombre;
                return $this;
        }

        public function getDescripcion() {
                return $this->descripcion;
        }

        public function setDescripcion($descripcion) {
                $this->descripcion = $descripcion;
                return $this;
        }

        public function getEstado() {
                return $this->estado;
        }

        public function setEstado($estado)  {
                $this->estado = $estado;
                return $this;
        }

        public function getImagen() {
                return $this->imagen;
        }

        public function setImagen($imagen) {
                $this->imagen = $imagen;
                return $this;
        }

    }//class
}//if exists
?>