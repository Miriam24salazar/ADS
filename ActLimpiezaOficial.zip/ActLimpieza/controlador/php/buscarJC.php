<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
</html>

<?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_actividad_dal.php");

    $id=strtoupper($_POST["f_idact"]);
    $nombre=strtoupper($_POST["f_nom"]);
    
    $actividad_ref=new actividad_dal;

    $existe_id=$actividad_ref->existe_actividad_id($id);

    if($existe_id==1){
        $actividad_ref=new actividad_dal;
        $actividad=$actividad_ref->datos_por_id($id);
        $array = array();
        array_push($array,$actividad);
        header('Content-type: application/json');
        return json_encode($array);
    }
    else{
        echo 'ERROR: Esta actividad no existe o no la puedes ver'
    }

    $existe_nombre=$actividad_ref->existe_actividad_nombre($id);

    if($existe_nombre==1){
        if()
        $actividad_ref=new actividad_dal;
        $actividad=$actividad_ref->datos_por_nombre($id);
        $array = array();
        array_push($array,$actividad);
        header('Content-type: application/json');
        return json_encode($array);
    }
    else{
        echo 'ERROR: Esta actividad no existe o no la puedes ver'
    }
?>