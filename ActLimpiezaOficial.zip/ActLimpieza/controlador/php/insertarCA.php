<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
    
</html>

<?php

    // ...

    // Mostrar los resultados en una tabla 
    include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_actividad_dal.php");
    $actividad_ref=new actividad_dal;
    $lista_act=$actividad_ref->lista_actividad();

    echo "<table>";
    while ($fila = mysqli_fetch_assoc($lista_act)) {
        echo "<tr>";
        echo "<td>" . $fila['id_actividad'] . "</td>";
        echo "<td>" . $fila['id_cuadrilla'] . "</td>";
        echo "<td>" . $fila['id_colonia'] . "</td>";
        echo "<td>" . $fila['nombre'] . "</td>";
        echo "<td>" . $fila['descripcion'] . "</td>";
        echo "<td>" . $fila['estado'] . "</td>";
        echo "<td>" . $fila['imagen'] . "</td>";
        // Agregar más columnas según la cantidad de campos de la tabla
        echo "</tr>";
    }
    echo "</table>";

        /*
    $nom=strtoupper($_POST["f_nom"]);
    $ape=strtoupper($_POST["f_ape"]);
    $con=$_POST["f_pwd"];
    $rfc=strtoupper($_POST["f_rfc"]);
    $gen=$_POST["f_gen"];
    //$cur=$_POST["f_curri"];
    $are=$_POST["areade"];

    $id_actividad=strtoupper($_POST["f_idact"]);;
    $id_cuadrilla=strtoupper($_POST["f_idcuad"]);;
    $id_colonia;
    $nombre;
    $descripcion;
    $estado;
    $imagen;
    $telefono;

    
    

    $existe=$actividad_ref->lista_actividad();

    echo "<ACTVDADES>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Nombre</th>";
    echo "<th>Descripción</th>";
    echo "</tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['nombre'] . "</td>";
        echo "<td>" . $row['descripcion'] . "</td>";
        echo "</tr>";
    }

    echo "</table>";

    // ...

    // Cerrar la conexión
    mysqli_close($conn);
    */
?>