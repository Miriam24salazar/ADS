<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Lista de Actividades</title>
    <meta name="description" content="">
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='css/estiloIS.css'>
    <script src='../controlador/validation/validationIS.js'></script>
</head>
<body>

    <div id="container">
        <form name="forma" enctype="multipart/form-data">
        <div class='container'>
            <h1>Lista de Actividades</h1>
        </div>
            <table>

                <?php
                include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_actividad_dal.php");

                $lisAct = new actividad_dal;
                $result_act = $lisAct->lista_actividad();
                if ($result_act==NULL){
                    echo '<h2>No se encontraron las actvdades</h2>';
                }
                else{ 
                    for($i = 1; $i <= count($result_act); $i++){
                        $actividad = $result_act[$i];
                        echo "<div class='container'>";
                        echo "<h2>------------ Actividad No. ".$actividad->getId_Actividad()." ------------</h2>";
                        echo "<p>Id actividad: ".$actividad->getId_Actividad()."</p>"; 
                        echo "<p>Id cuadrilla: ".$actividad->getId_Cuadrilla()."</p>"; 
                        echo "<p>Id colonia: ".$actividad->getId_Colonia()."</p>"; 
                        echo "<p>Nombre: ".$actividad->getNombre()."</p>"; 
                        echo "<p>Descripción: ".$actividad->getDescripcion()."</p>"; 
                        echo "<p>Estado: ".$actividad->getEstado()."</p>";
                        echo "<p>Imagen: </p><br><img src='".$actividad->getImagen()."' width='300px'></div>"; 
                }
            }
    ?>        
        </table>
    

        <div id="row">
            <input type="submit" value="Regresar">
        </div>
        
    </form>
</div><!-- end Inicio de Sesion -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>
</html>