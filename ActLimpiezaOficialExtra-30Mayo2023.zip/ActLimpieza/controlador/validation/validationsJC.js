// arrow function
/*
let valida_JEFECUADRILA = () => {
    let js_idact=document.getElementById("f_idact").value;
    let js_nom=document.getElementById("f_nom").value.trim();
    let js_col=document.getElementById("f_col").value.trim();
    let js_des=document.getElementById("f_des").value.trim();
    let imagen=document.getElementById("f_imagen").value;

    const js_estado=document.getElementsByName("f_estado");
    let radioSelected = false;
 
    for (let i = 0; i < js_estado.length; i++) {
        if (js_estado[i].checked) {
            radioSelected = true;
            break;
        }
    }
    */
    /*
    if (js_idact == 0){
        //alert("El ID ACTIVIDAD no puede ir vacio");   
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: El Id Actividad no puede ir vacío!'
        });
        return false;
    } 
    else if (js_nom.length == 0) {
        //alert("El nombre no puede estar vacío"); 
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: El nombre no puede ir vacío!' 
        }); 
        return false;
    } 
    else if (js_col == 0){
        //alert("El ID ACTIVIDAD no puede ir vacio");   
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: La colonia no puede ir vacía!'
        });
        return false;
    } 
    else if (js_des == 0){
        //alert("La descripcion no puede ir vacia");  
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: La descripción no puede ir vacía!'
        });
        return false;
    } 
    else if (imagen == 0){
        //alert("La imagen no puede ir vacia"); 
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: Debe selecionar una imagen!'
        });  
        return false;
    }
    else if (!radioSelected) {
        //alert("Seleccione un estado");
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: Debe selecionar un estado!'
        });
        return false;
    }  
    */            
}

function valida_actjefe() {
    var js_nom = document.getElementById("f_nom").value.trim();    
}