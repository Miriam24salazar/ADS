

<?php

function Buscar() {
    $actividad_ref=new actividad_dal;

    $id_actividad=strtoupper($_POST["f_idact"]);
    $id_cuadrilla=$_POST["cuad"];
    $id_colonia=$_POST["col"];
    $nombre=strtoupper($_POST["f_nom"]);
    $descripcion=strtoupper($_POST["f_des"]);
    $estado=$_POST["f_estado"];
    //$image=$_POST["f_imag"];
    $existe=$actividad_ref->lista_actividad();
    


        if(isset($_FILES["f_imag"]) && $_FILES["f_imag"]["error"] == 0){
            $valid_extensions = array('jpeg', 'jpg', 'png', 'JPEG', 'JPG', 'PNG'); // valid extensions
            $path = '../uploads/'; // upload directory
            $img = $_FILES["f_imag"]["name"]; //stores the original filename from the client
            $tmp = $_FILES["f_imag"]["tmp_name"]; //stores the name of the designated temporary file
            $filesize = $_FILES["f_imag"]["size"];//get size in bytes of archivo,ja
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));// get uploaded file's extension
            //$final_image = rand(1000,1000000).$img;// can upload same image using rand function
            $final_file = $rfc.'.'.$ext;//nombre final de la imagen para subir
            $path = $path.$final_file;//coloca nombre de archivo
            //$maxsize = .5 * 1024 * 1024;
            $maxsize = 4 * 1024 * 1024;
    
    
        }
        else{
                echo "Error: No existe o esta dañado:" . $_FILES["f_imag"]["error"];//stores any error code resulting from the transfer
            }
        }
        $id_actividad=strtoupper($_POST["f_idact"]);
        

          header('Location: /ActLimpieza/vista/bus_cua.php?f_idact='.$id_actividad);
        /*
    $nom=strtoupper($_POST["f_nom"]);
    $ape=strtoupper($_POST["f_ape"]);
    $con=$_POST["f_pwd"];
    $rfc=strtoupper($_POST["f_rfc"]);
    $gen=$_POST["f_gen"];
    //$cur=$_POST["f_curri"];
    $are=$_POST["areade"];

    $id_actividad=strtoupper($_POST["f_idact"]);;
    $id_cuadrilla=strtoupper($_POST["f_idcuad"]);;
    $id_colonia;
    $nombre;
    $descripcion;
    $estado;
    $imagen;
    $telefono;



    $existe=$actividad_ref->lista_actividad();

    echo "<ACTVDADES>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Nombre</th>";
    echo "<th>Descripción</th>";
    echo "</tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row->getid'] . "</td>";
        echo "<td>" . $row->getnombre'] . "</td>";
        echo "<td>" . $row->getdescripcion'] . "</td>";
        echo "</tr>";
    }

    echo "</table>";

    // ...

    // Cerrar la conexión
    mysqli_close($conn);
    */

    
?>