<?php
    include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_actividad_dal.php");
    function listaActCuad($cuadrilla){

        $actividad_ref=new actividad_dal();
        $lista=$actividad_ref->lista_actividad();
        $i=0;
        
        foreach($lista as $actividad){
            if($actividad->getId_Cuadrilla()==$cuadrilla){

                $listachida[$i]=$actividad;
                $i++;
            }
        }

        return $listachida;

    }
?>