<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.css"/>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
</html>

<?php
include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_usuarios_dal.php");
    include("C:xampp/htdocs/ActLimpieza/modelo/class/class_cuenta_dal.php");
    $cuenta_ref=new cuenta_dal;
    
    $us=strtoupper($_POST["f_us"]);
    $con=$_POST["f_pwd"];
    $id_cuen="SELECT id_cuenta FROM cuenta WHERE usuario='$us'";

    $obj_cuenta= new cuenta($id_cuen, $us, $con, null);
    
    //VALIDAR SI EXISTE
    $existe=$cuenta_ref->existe_cuenta($us);
    if ($existe==1){ 
        $cuenta_ref=new cuenta_dal();
        $cuenta = $cuenta_ref-> buscar_cuenta($us);
        if($cuenta['contrasena'] == $con){
            $cuenta_ref=new cuenta_dal();
            $cuenta = $cuenta_ref-> buscar_cuenta($us);
            if($cuenta['contrasena'] == $con){
                $usuario_ref=new usuarios_dal();
                $usuario = $usuario_ref->datos_por_id_cuenta($cuenta['id_cuenta']);
                
                //$actividad_ref=new actividad_dal;
                //$actividad=$usuario_ref->datos_por_cuadrilla($cuadrilla['id_cuadrilla']);
                //$cuadrilla_ref=new cuadrilla_dal;
                //$usuario_cua = $usuario_ref->datos_por_cuadrilla($cuadrilla['id_cuadrilla']);

                if($usuario->getTipoUsuario() == "admin"){
                    header('Location: /ActLimpieza/vista/menu_admin.php');
                }
                elseif($usuario->getTipoUsuario() == "jefe"){
                    header('Location: /ActLimpieza/vista/jefe_cuadrilla.php?id_cuadrilla='.$usuario->getId_Cuadrilla());
                }
                elseif($usuario->getTipoUsuario() == "intCuadrilla"){
                    header('Location: /ActLimpieza/vista/cuadrilla_act.php?id_cuadrilla='.$usuario->getId_Cuadrilla());
                }

                
            }
        }
            
    }
    else {
        //echo "El usuario NO esta registrado";

        header('Location: /ActLimpieza/vista/index.php');
    }

?>