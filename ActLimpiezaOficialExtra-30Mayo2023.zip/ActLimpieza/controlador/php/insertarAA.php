<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
</html>

<?php

    include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_actividad_dal.php");
    $actividad_ref=new actividad_dal;

        //Registrar
        $idact=$_POST["f_idact"];
        $nombre=$_POST["f_nom"];
        $cuad=$_POST["cuad"];
        $col=$_POST["col"];
        $des=$_POST["f_des"];
        $img=$_POST["f_imag"];
        $estado=$_POST["f_estado"];
        
        $actividad = new actividad($idact, $cuad, $col, $nombre, $des, $estado, $img);
        $agregar=$actividad_ref->insertar_actividad($actividad);
        if($agregar==1){
            echo "Registro hecho correctamente";
        }
        else{
            echo "No se pudo registrar";
        }
        //end Registrar
        
    
    function Buscar() {
        $actividad_ref=new actividad_dal;

        $id_actividad=strtoupper($_POST["f_idact"]);
        $id_cuadrilla=$_POST["cuad"];
        $id_colonia=$_POST["col"];
        $nombre=strtoupper($_POST["f_nom"]);
        $descripcion=strtoupper($_POST["f_des"]);
        $estado=$_POST["f_estado"];
        //$image=$_POST["f_imag"];

        $existe=$actividad_ref->lista_actividad();
        

        if ($_FILES['f_imag']['name'] != null) {

            if(isset($_FILES["f_imag"]) && $_FILES["f_imag"]["error"] == 0){
                $valid_extensions = array('jpeg', 'jpg', 'png', 'JPEG', 'JPG', 'PNG'); // valid extensions
                $path = '../uploads/'; // upload directory
                $img = $_FILES["f_imag"]["name"]; //stores the original filename from the client
                $tmp = $_FILES["f_imag"]["tmp_name"]; //stores the name of the designated temporary file
                $filesize = $_FILES["f_imag"]["size"];//get size in bytes of archivo,ja
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));// get uploaded file's extension
                //$final_image = rand(1000,1000000).$img;// can upload same image using rand function
                $final_file = $rfc.'.'.$ext;//nombre final de la imagen para subir
                $path = $path.$final_file;//coloca nombre de archivo
                //$maxsize = .5 * 1024 * 1024;
                $maxsize = 4 * 1024 * 1024;
        
        
            }
            else{
                    echo "Error: No existe o esta dañado:" . $_FILES["f_imag"]["error"];//stores any error code resulting from the transfer
                }
            }
            else{
                $final_file=null;
            }
    }

    
    
?>