<?php
    include("class_colonia.php");
    include("class_db.php");

    class colonia_dal extends class_db{
        function __construct(){
            parent::__construct();
        }

        function __destruct(){
            parent::__destruct();
        }

        public function datos_por_codigoPostal($codigoPostal){
            $codigoPostal=$this->db_conn->real_escape_string($codigoPostal);
            $sql="SELECT * FROM colonia WHERE codigoPostal= $codigoPostal";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_codigoPostal=mysqli_num_rows($result);
            $obj_det=null;
            if($total_codigoPostal==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new colonia(
                    $renglon["id_colonia"],
                    $renglon["codigoPostal"],
                    $renglon["asentamiento"],
                    $renglon["tipo_asentamiento"]);
            }

            return $obj_det;
        }

        function lista_colonia(){
            $sql="select * from colonia;";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_rfc=mysqli_num_rows($result);
            $obj_det=null;

            if ($total_rfc>0){
                $i=0;
                while($renglon = mysqli_fetch_assoc($result)){
                    $obj_det= new colonia(
                        $renglon["id_colonia"],
                        $renglon["codigoPostal"],
                        $renglon["asentamiento"],
                        $renglon["tipo_asentamiento"]);

                        $i++;
                        $lista[$i]=$obj_det;
                        unset($obj_det); 
                }//end while
                return $lista;
            }

        public function datos_por_asentamiento($asentamiento){
            $asentamiento=$this->db_conn->real_escape_string($asentamiento);
            $sql="SELECT * FROM colonia WHERE asentamiento= $asentamiento";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_asentamientol=mysqli_num_rows($result);
            $obj_det=null;
            if($total_asentamientol==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new colonia(
                    $renglon["id_colonia"],
                    $renglon["codigoPostal"],
                    $renglon["asentamiento"],
                    $renglon["tipo_asentamiento"]);
            }

            return $obj_det;
        }

        public function datos_por_id_colonia($id_colonia){
            $id_colonia=$this->db_conn->real_escape_string($id_colonia);
            $sql="SELECT * FROM colonia WHERE id_colonia= $id_colonia";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_id_colonia=mysqli_num_rows($result);
            $obj_det=null;
            if($total_id_colonia==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new colonia(
                    $renglon["id_colonia"],
                    $renglon["codigoPostal"],
                    $renglon["asentamiento"],
                    $renglon["tipo_asentamiento"]);
            }

            return $obj_det;
        }

        function existe_colonia($codigoPostal){
            $codigoPostal=$this->db_conn->real_escape_string($codigoPostal);
            $sql = "SELECT count(*) FROM colonia";
            $sql.=" WHERE codigoPostal = $codigoPostal";

            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }

        
        function buscar_asentamiento($obj){
            $sql = "SELECT asentamiento FROM colonia";
            $sql .= " WHERE id_colonia = ".$obj->getId_Colonia();
            
            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }

        function buscar_codigoPostal($obj){
            $sql = "SELECT codigoPostal FROM colonia";
            $sql .= " WHERE id_colonia = ".$obj->getId_Colonia();
            
            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }

        function insertar_colonia($obj){
            
            $sql="INSERT INTO colonia(";
            $sql.="id_colonia,";
            $sql.="codigoPostal,";
            $sql.="asentamiento,";
            $sql.="tipo_asentamiento)";            
            $sql.=" VALUES (";
            $sql.=$obj->getId_Colonia().",";    
            $sql.="'".$obj->getCodigoPostal()."',";
            $sql.="'".$obj->getAsentamiento()."',";
            $sql.="'".$obj->getTipo_Asentamiento()."'";
            $sql.=")";

            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $insertado=1;
                }
                else{
                    $insertado=0;
                }
                unset($obj);
            return $insertado;
        }//end function        

        function borra_colonia($id_colonia){
            $id_colonia=$this->db_conn->real_escape_string($id_colonia);
            $sql="DELETE FROM colonia WHERE id_colonia= $id_colonia";
            //echo $sql;return;
            $this->set_sql($sql);
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $borrado=1;
                }
                else{
                    $borrado=0;
                }

                unset($obj);
                return $borrado;
        }

        function actualiza_colonia($obj){
            $sql = "UPDATE colonia SET ";
            $sql .= "codigoPostal="."'".$obj->getCodigoPostal()."',";
            $sql .= "asentamiento="."'".$obj->getAsentamiento()."',";
            $sql .= "tipo_asentamiento="."'".$obj->getTipo_Asentamiento()."',";
            $sql .= " WHERE id_colonia = ".$obj->getId_Colonia();
            
            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
            
            mysqli_query($this->db_conn,$this->db_query) 
            or die(mysqli_error($this->db_conn));
                
                if(mysqli_affected_rows($this->db_conn)==1) {
                    $actualizado=1;
                }            
                else{
                    $actualizado=0;
                }
            unset($obj);
            return $actualizado;
        }
        
    }//end class
?>