<?php
class DatabaseConnection {
    private static $instance = null;
    public $db_conn;

    private function __construct() {
        $this->db_conn = mysqli_connect('localhost', 'usuario', 'contraseña', 'basededatos');
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
}

$db = DatabaseConnection::getInstance();

$sql = "SELECT * FROM cuenta";
$result = mysqli_query($db->db_conn, $sql);
while ($fila = mysqli_fetch_array($result)) {
    echo '<p>';
    echo json_encode($fila);
    echo '</p>';
}
?>