<?php
if (class_exists("colonia")!=true) {
    class colonia{
        protected $id_colonia;
        protected $codigoPostal;
        protected $asentamiento;    
        protected $tipo_asentamiento;

        public function __construct(
            $id_colonia=NULL,
            $codigoPostal=NULL,
            $asentamiento=NULL,
            $tipo_asentamiento=NULL) {
                $this->id_colonia=$id_colonia;
                $this->codigoPostal=$codigoPostal;
                $this->asentamiento=$asentamiento;  
                $this->tipo_asentamiento=$tipo_asentamiento;
        }
        
        public function getId_Colonia() {
            return $this->id_colonia;
        }

        public function setId_Colonia($id_colonia) {
            $this->id_colonia = $id_colonia;
            return $this;
        }

        public function getCodigoPostal() {
            return $this->codigoPostal;
        }

        public function setCodigoPostal($codigoPostal) {
            $this->codigoPostal = $codigoPostal;
            return $this;
        }

        public function getAsentamiento() {
            return $this->asentamiento;
        }

        public function setAsentamiento($asentamiento) {
            $this->asentamiento = $asentamiento;
            return $this;
        }

        public function getTipo_Asentamiento() {
            return $this->tipo_asentamiento;
        }

        public function setTipo_Asentamiento($tipo_asentamiento) {
            $this->tipo_asentamiento = $tipo_asentamiento;
            return $this;
        }

    }//class
}
?>