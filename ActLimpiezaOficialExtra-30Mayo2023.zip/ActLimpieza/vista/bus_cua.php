<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Integrante de la cuadrilla</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type='text/css' href="css/estiloC.css">
    <script src="../controlador/validation/validationCA.js"></script>
</head>
<body>
    <div id="container">
            <h1>Actividad</h1>
            <div id="row">

            <?php
                // Mostrar los resultados en una tabla 
                include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_actividad_dal.php");
                $actividad_ref = new actividad_dal;
                $id_actividad = strtoupper($_GET["f_idact"]);
                $fila = $actividad_ref->datos_por_id($id_actividad);

                echo "<ul>";
                echo "<li>ID Actividad: ".$fila->getId_Actividad()."</li>";
                echo "<li id='id' value='".$fila->getID_Cuadrilla()."'>ID Cuadrilla: ".$fila->getId_Cuadrilla()."</li>";
                echo "<li>ID Colonia: ".$fila->getId_Colonia()."</li>";
                echo "<li>Nombre: ".$fila->getNombre()."</li>";
                echo "<li>Descripción: ".$fila->getDescripcion()."</li>";
                echo "<li>Estado: ".$fila->getEstado()."</li>";
                echo "<li>Imagen: ".$fila->getImagen()."</li>";
                echo "</ul>";
                ?>
          
</div>
            <div id="row">
                <input type="submit" value="Regresar" onclick="regresar()">
            </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function regresar(){
            var id = document.getElementById("id").value;
            window.location.href="cuadrilla_act.php?id_cuadrilla="+id;
        }
    </script>
</body>
</html>
