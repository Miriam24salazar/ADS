function Cuadrilla(){
    window.location.href = "admin_cuad.php";
}

function Actividades(){
    window.location.href = "admin_act.php";
}

function ListaAct(){
    window.location.href = "admin_listaAct.php";
}

function Colonias(){
    window.location.href = "admin_col.php";
}

function Usuarios(){
    window.location.href = "admin_jt.php";
}

function CerrarSesion(){
    //window.location.href = "C:/xampp/htdocs/ActLimpieza/vista/index.php";
    header('Location: /ActLimpieza/vista/index.php');
}

function Regresar(){
    window.location.href = "C:/xampp/htdocs/ActLimpieza/vista/menu_admin.php";
}
