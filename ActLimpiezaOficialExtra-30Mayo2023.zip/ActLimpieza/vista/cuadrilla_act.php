<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Integrante de la cuadrilla</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type='text/css' href="css/estiloC.css ">
        <script src='../controlador/validation/validationCA.js'></script>
        <script src='../controlador/validation/buscar.js'></script>

    </head>
    <body>


        <div id="container">
            <form name="forma" action="../controlador/php/insertarCA.php" method="post">
            <h1>Integrante de la cuadrilla</h1>
            <h1>--ACTIVIDADES--</h1>

           
            <div id="row">
                <label for="id_actividad">No. Actividad:</label>
                <select id="f_idact" name="f_idact">
                    <option value="0">Seleccione o escriba una actividad:</option>
                    <?php
                    include("C:/xampp/htdocs/ActLimpieza/controlador/php/lista_act.php");
                        $lista=listaActCuad($_GET["id_cuadrilla"]);
                        foreach($lista as $actividad){
                            echo '<option value= "'.$actividad->getId_Actividad().'">'.$actividad->getId_Actividad().'</option>';
                        }
                    ?>
                </select>
            </div>

            <div id="row">
                <label for="nombre">Nombre de la Actividad:</label>
                <input type="text" id="f_nom" name="f_nom" placeholder="Aquí va el Nombre de Actividad">
            </div>

            <div id="row">
                &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             
                <input type="submit" value="Buscar"  onclick="return Buscar()">
            </div>

            <div id="row">
                <label for="col">Colonia:</label>
                <input type="text" id="f_col" name="f_col" placeholder="Aquí va la colonia">
            </div>

            <div id="row">
                <label for="descripcion">Descripción:</label>
                <input type="text" id="f_des" name="f_des" placeholder="Aquí va la descripción">
            </div>

            <div id="row">
                <label for="imagen">Imagen:</label> 
                <input type="file" id="f_imagen" name="f_imagen">
            </div>

            <div id="row">

                <label for="estado">ESTADO:<br><br></label>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <label for="Hecho"> Hecho:</label>
                <input type="radio" id="f_hecho" name="f_estado" value="H"><br>

                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <label for="Activo"> Activo:</label>
                <input type="radio" id="f_activo" name="f_estado" value="A"><br>
                
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <label for="Inactivo">Inactivo:</label>
                <input type="radio" id="f_inactivo" name="f_estado" value="I">
            
            </div>
        
            </form>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </body>
</html>
