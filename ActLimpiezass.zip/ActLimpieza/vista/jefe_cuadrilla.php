<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Jefe de la cuadrilla</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type='text/css' href="css/estiloC.css ">
        <script src='../controlador/validation/validationsJC.js'></script>
    </head>
    <body>


        <div id="container">
            <form name="forma" action="../controlador/php/insertarJC.php" method="post" onsubmit="return valida_JEFECUADRILA();">
            <h1>Jefe de la cuadrilla</h1>
            <h1>--ACTIVIDADES--</h1>

            <div id="row">
            &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             
                <input type="button" value="BUSCAR" onclick="Buscar()">
            </div>

            <div id="row">
                <label for="id_actividad">No. Actividad:</label>
                <input type="text" id="f_idact" name="f_idact" placeholder="Aquí va el Número de Actividad">
            </div>

            <div id="row">
                <label for="nombre">Nombre de la Actividad:</label>
                <input type="text" id="f_nom" name="f_nom" placeholder="Aquí va el Nombre de Actividad">
            </div>

            <div id="row">
                <label for="col">Colonia:</label>
                <input type="text" id="f_col" name="f_col" placeholder="Aquí va la colonia">
            </div>

            <div id="row">
                <label for="descripcion">Descripción:</label>
                <input type="text" id="f_des" name="f_des" placeholder="Aquí va la descripción">
            </div>

            <div id="row">
                <label for="imagen">Imagen:</label> 
                <input type="file" id="f_imagen" name="f_imagen">
            </div>

            <div id="row">

                <label for="estado">ESTADO:<br><br></label>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <label for="Hecho"> Hecho:</label>
                <input type="radio" id="f_hecho" name="f_estado" value="H"><br>

                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <label for="Activo"> Activo:</label>
                <input type="radio" id="f_activo" name="f_estado" value="A"><br>
                
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <label for="Inactivo">Inactivo:</label>
                <input type="radio" id="f_inactivo" name="f_estado" value="I">
            
            </div>
        
            <div id="row">
                <input type="submit" value="Registrar">
                <input type="reset" value="Limpiar">
                <input type="submit" value="Cerrar Sesion">
            </div>
            </form>
            <script src="scripts/scriptJC.js"></script>
        </div>                
    </body>
</html>
