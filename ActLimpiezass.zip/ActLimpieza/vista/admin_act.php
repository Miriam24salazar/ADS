<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Actividad</title>
        <meta name="description" content="">
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <link rel='stylesheet' type='text/css' media='screen' href='css/estiloAA.css'>
        <script src='../controlador/validation/validationAA.js'></script>
    </head>
    <body>
        <div id="container">
            <form name="forma" enctype="multipart/form-data" action="../controlador/php/insertarAA.php" method="post" onsubmit="return valida_adminAct();">
                <h1>ACTIVIDADES</h1>
                <h2>Muestra y registros</h2>
                <h3>----------------------------------------------</h3>
                
                
                <div id="row">
                    <label for="idact">No. Actividad:</label>
                    <input type="text" id="f_idact" name="f_idact" placeholder="Escriba un número de actividad">
                </div>

                <div id="row">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="f_nom" name="f_nom" placeholder="Escriba un nombre a la actividad">
                </div>

                <div id="row">
                    <label for="cuad">Cuadrilla:</label>
                    <select id="cuad" name="cuad">
                        <option value="0">Seleccione o escriba una cuadrilla:</option>
                        <option value="1">Cuadrilla 1</option>
                        <option value="2">Cuadrilla 2</option>
                        <option value="3">Cuadrilla 3</option>
                    </select>
                </div>

                <div id="row">
                <div id="row">
                    <label for="col">Colonia:</label>
                    <select id="col" name="col">
                        <option value="0">Seleccione o escriba una colonia:</option>
                        <option value="1">Colonia 1</option>
                        <option value="2">Colonia 2</option>
                        <option value="3">Colonia 3</option>
                    </select>
                </div>

                <div id="row">
                    <label for="descripcion">Descripción:</label>
                    <input type="text" id="f_des" name="f_des" placeholder="Escriba una descripción">
                </div>

                <div id="row">
                    <label for="imag">Imagen:</label> 
                    <input type="file" id="f_imag" name="f_imag">
                </div>
                
                <div id="row">
                    <label for="f_estado">Estado:</label> <br>
                    
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <label for="Hecho"> Hecho:</label>
                    <input type="radio" id="f_hecho" name="f_estado" value="H"><br>

                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <label for="Activo"> Activo:</label>
                    <input type="radio" id="f_activo" name="f_estado" value="A"><br>
                    
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <label for="Inactivo">Inactivo:</label>
                    <input type="radio" id="f_inactivo" name="f_estado" value="I">
                </div>
            
                <div id="row">
                    <input type="submit" value="Registrar">
                    <input type="submit" value="Buscar">
                </div>

                <div id="row">
                    <input type="submit" value="Actualizar">
                </div>

                <div id="row">
                    <input type="reset" value="Eliminar">
                    <input type="reset" value="Limpiar">
                </div>

                <div id="row">
                    <input type="submit" value="Cerrar Sesión">
                    <input type="submit" value="Regresar">
                </div>

            </form>
        </div><!-- end container -->
        
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </body>
</html>