function Cuadrilla(){
    window.location.href = "admin_cuad.php";
}

function Actividades(){
    window.location.href = "admin_act.php";
}

function Colonias(){
    window.location.href = "admin_col.php";
}

function Usuarios(){
    window.location.href = "admin_jt.php";
}