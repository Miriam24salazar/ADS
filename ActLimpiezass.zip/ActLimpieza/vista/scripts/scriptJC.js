var idAct = document.getElementById("f_idact");
var nombre = document.getElementById("f_nom");
var colonia = document.getElementById("f_col");
var descripcion = document.getElementById("f_des");
var imagen = document.getElementById("f_imagen");
var hecho = document.getElementById("f_hecho");
var activo = document.getElementById("f_activo");
var inactvio = document.getElementById("f_inactivo");

function Buscar(){
    fetch('../controlador/php/buscarJC.php?idAct' + idAct.value + "&nombre=" + nombre.value)
    .then(response => response)
    .then(data =>{
        console.log(data);
        if(data.lenght > 0){
            colonia.value = data[2];
            nombre.value = data[3];
            descripcion.value = data[4];
            var estado = data[5];
            imagen.value = data[6];
            if(estado == 'H'){
                hecho.checked = true;
            }
            else if(estado == 'A'){
                activo.checked = true;
            }
            else{
                inactvio.checked = true;
            }
        }
    })

}