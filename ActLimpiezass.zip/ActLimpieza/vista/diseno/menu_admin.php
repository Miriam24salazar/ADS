<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Menu de Admin</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type='text/css' href="../css/estiloA.css ">
        <script src='../controlador/validation/validationA.js'></script>
    </head>
    <body>
        <div id="container"><!-- admin -->
            <form name="forma" action="php/insertarA.php" method="post" onsubmit="return valida_admin();">
            <h1>ADMINISTRADOR</h1>
            <h2>Menú</h2>
            <h3>---------------------------------------------</h3>
                
            <div id="row">
                <label for="cuadrillas">Cuadrillas</label>
                <input type="submit" value="Mostrar">
            </div>

            <div id="row">
                <label for="act">Actividades</label>
                <input type="submit" value="Mostrar">
            </div>

            <div id="row">
                <label for="col">Colonias</label>
                <input type="submit" value="Mostrar">
            </div>

            <div id="row">
                <label for="jt">Jefes y </label><br>
                <label for="jt2">Trabajadores</label>
                <input type="submit" value="Mostrar">
            </div>

            <div id="row">
                <input type="submit" value="Cerrar Sesión">
            </div>
            </form>
        </div> <!-- end admin -->

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
               
    </body>
</html>