<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Actividad</title>
        <meta name="description" content="">
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <link rel='stylesheet' type='text/css' media='screen' href='../css/estiloAA.css'>
        <script src='../controlador/validation/validationAA.js'></script>
    </head>
    <body>
        <div id="container">
            <form name="forma" enctype="multipart/form-data" action="php/insertar.php" method="post" onsubmit="return valida_adminAct();">
                <h1>ACTIVIDADES</h1>
                <h2>Muestra y registros</h2>
                <h3>----------------------------------------------</h3>
                
                <div id="row">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="f_nom" name="f_nom" placeholder="Escriba un nombre a la actividad">
                </div>

                <div id="row">
                    <label for="nAct">No. Actividad:</label>
                    <input type="text" id="f_nAct" name="f_nAct" placeholder="Escriba un número de actividad">
                </div>
                
                <div id="row">
                    <label for="descripcion">Descripción:</label>
                    <input type="text" id="f_des" name="f_des" placeholder="Escriba una descripción">
                </div>

                <div id="row">
                    <label for="cuad">Cuadrilla:</label>
                    <select id="cuad" name="cuad">
                        <option value="0">Seleccione o escriba una cuadrilla:</option>
                        <option value="1">Cuadrilla 1</option>
                        <option value="2">Cuadrilla 2</option>
                        <option value="3">Cuadrilla 3</option>
                    </select>
                </div>

                <div id="row">
                    <label for="col">Colonia:</label>
                    <select id="col" name="col">
                        <option value="0">Seleccione o escriba una colonia:</option>
                        <option value="1">Colonia 1</option>
                        <option value="2">Colonia 2</option>
                        <option value="3">Colonia 3</option>
                    </select>
                </div>

                
                <div id="row">
                    <label for="f_estado">Estado:</label> <br>
                    
                    <input type="radio" id="f_h" name="f_estado" value="H">
                    <span>Hecho</span>

                    <input type="radio" id="f_a" name="f_estado" value="A">
                    <span>Activo</span>
                    
                    <input type="radio" id="f_i" name="f_estado" value="I">
                    <span>Inactivo</span>
                </div>

                <div id="row">
                    <label for="imag">Imagen:</label> 
                    <input type="file" id="f_imag" name="f_imag">
                </div>
            
                <div id="row">
                    <input type="submit" value="Registrar">
                    <input type="submit" value="Buscar">
                </div>

                <div id="row">
                    <input type="submit" value="Registrar">
                    <input type="submit" value="Actualizar">
                </div>

                <div id="row">
                    <input type="reset" value="Borrar">
                    <input type="reset" value="Limpiar">
                </div>

            </form>
        </div><!-- end container -->
        
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </body>
</html>