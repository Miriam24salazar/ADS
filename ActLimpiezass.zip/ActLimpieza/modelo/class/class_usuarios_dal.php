<?php
    include("class_usuarios.php");
    include("class_db.php");

    class usuarios_dal extends class_db{
        function __construct(){
            parent::__construct();
        }

        function __destruct(){
            parent::__destruct();
        }

        public function datos_por_id_cuenta($id_cuenta){
            $id_cuenta=$this->db_conn->real_escape_string($id_cuenta);
            $sql="SELECT * FROM usuarios WHERE id_cuenta= $id_cuenta";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_id_cuenta=mysqli_num_rows($result);
            $obj_det=null;
            if($total_id_cuenta==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new usuarios(
                    $renglon["id_usuario"],
                    $renglon["nombre"],
                    $renglon["apellido"],
                    $renglon["tipoUsuario"],
                    $renglon["correo"],
                    $renglon["telefono"],
                    $renglon["id_cuenta"],
                    $renglon["id_cuadrilla"]);
            }

            return $obj_det;
        }

        public function datos_por_usuario($id_usuario){
            $id_usuario=$this->db_conn->real_escape_string($id_usuario);
            $sql="SELECT * FROM usuarios WHERE id_usuario= $id_usuario";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_id_usuario=mysqli_num_rows($result);
            $obj_det=null;
            if($total_id_usuario==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new usuarios(
                    $renglon["id_usuario"],
                    $renglon["nombre"],
                    $renglon["apellido"],
                    $renglon["tipoUsuario"],
                    $renglon["correo"],
                    $renglon["telefono"],
                    $renglon["id_cuenta"],
                    $renglon["id_cuadrilla"]);
            }

            return $obj_det;
        }

        function existe_usuario($id_cuenta){
            $id_cuenta=$this->db_conn->real_escape_string($id_cuenta);
            $sql = "SELECT count(*) FROM usuarios";
            $sql.=" WHERE id_cuenta= $id_cuenta";

            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }

        function insertar_usuario($obj){
            
            $sql="INSERT INTO usuarios(";
            $sql.="id_usuario,";
            $sql.="nombre,";
            $sql.="apellido,";
            $sql.="tipoUsuario,";
            $sql.="correo,";
            $sql.="telefono,";
            $sql.="id_cuenta,";                                                   
            $sql.="id_cuadrilla)";            
            $sql.=" VALUES (";
            $sql.=$obj->getId_Usuario().",";    
            $sql.="'".$obj->getNombre()."',";
            $sql.="'".$obj->getApellido()."',";
            $sql.="'".$obj->getTipoUsuario()."',";
            $sql.="'".$obj->getCorreo()."',";
            $sql.= $obj->getTelefono().",";
            $sql.= $obj->getId_Cuenta().",";
            $sql.= $obj->getId_Cuadrilla();
            $sql.=")";

            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $insertado=1;
                }
                else{
                    $insertado=0;
                }
                unset($obj);
                return $insertado;
        }//end function        

        function borra_usuario($id_usuario){
            $id_usuario=$this->db_conn->real_escape_string($id_usuario);
            $sql="DELETE FROM usuarios WHERE id_usuario= $id_usuario";
            //echo $sql;return;
            $this->set_sql($sql);
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $borrado=1;
                }
                else{
                    $borrado=0;
                }

                unset($obj);
                return $borrado;
        }

        function actualiza_usuario($obj){
            /*
                    echo '<pre>';
                    echo print_r($obj);
                    echo '</pre>';
                    exit;
            */
            $sql = "UPDATE usuarios SET ";
            $sql .= "nombre = "."'".$obj->getNombre()."',";
            $sql .= "apellido = "."'".$obj->getApellido()."',";
            $sql .= "tipoUsuario = "."'".$obj->getTipoUsuario()."',";                
            $sql .= "correo = "."'".$obj->getCorreo()."',";
            $sql .= "telefono = ".$obj->getTelefono().",";
            $sql .= "id_cuenta = ".$obj->getId_Cuenta().",";
            $sql .= "id_cuadrilla = ".$obj->getId_Cuadrilla();
            $sql .= " WHERE id_usuario = ".$obj->getId_Usuario();

            //echo $sql;//exit;
            
            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
                    
            mysqli_query($this->db_conn,$this->db_query) 
            or die(mysqli_error($this->db_conn));         
            
                if(mysqli_affected_rows($this->db_conn)==1) {
                    $actualizado=1;
                }
                else{
                    $actualizado=0;
                }
            unset($obj);
            return $actualizado;
        }

    }//end class
?>