<?php
if (class_exists("usuarios")!=true){
    class usuarios{
        protected $id_usuario;
        protected $nombre;
        protected $apellido;
        protected $tipoUsuario;
        protected $correo;
        protected $telefono;
        protected $id_cuenta;
        protected $id_cuadrilla;

        public function __construct(
            $id_usuario=NULL,
            $nombre=NULL,
            $apellido=NULL,
            $tipoUsuario=NULL,
            $correo=NULL,
            $telefono=NULL,
            $id_cuenta=NULL,
            $id_cuadrilla=NULL) {
                $this->id_usuario=$id_usuario;
                $this->nombre=$nombre;
                $this->apellido=$apellido;
                $this->tipoUsuario=$tipoUsuario;
                $this->correo=$correo;
                $this->telefono=$telefono;
                $this->id_cuenta=$id_cuenta;
                $this->id_cuadrilla=$id_cuadrilla;
        }
        
        public function getId_Usuario() {
            return $this->id_usuario;
        }

        public function setId_Usuario($id_usuario) {
                $this->id_usuario = $id_usuario;
                return $this;
        }

        public function getNombre() {
                return $this->nombre;
        }

        public function setNombre($nombre) {
                $this->nombre = $nombre;
                return $this;
        }

        public function getApellido() {
                return $this->apellido;
        }

        public function setApellido($apellido) {
                $this->apellido = $apellido;
                return $this;
        }

        public function getTipoUsuario() {
                return $this->tipoUsuario;
        }

        public function setTipoUsuario($tipoUsuario)  {
                $this->tipoUsuario = $tipoUsuario;
                return $this;
        }

        public function getCorreo() {
                return $this->correo;
        }

        public function setCorreo($correo) {
                $this->correo = $correo;
                return $this;
        }

        public function getTelefono() {
                return $this->telefono;
        }

        public function setTelefono($telefono) {
                $this->telefono = $telefono;
                return $this;
        }

        public function getId_Cuenta() {
            return $this->id_cuenta;
        }

        public function setId_Cuenta($id_cuenta) {
                $this->id_cuenta = $id_cuenta;
                return $this;
        }

        public function getId_Cuadrilla() {
                return $this->id_cuadrilla;
        }

        public function setId_Cuadrilla($id_cuadrilla) {
                $this->id_cuadrilla = $id_cuadrilla;
                return $this;
        }

    }//class
}//if exists
?>