
//arrow function
let valida_inicio = () =>{
    let js_us=document.getElementById("f_us").value.trim();
    let js_con=document.getElementById("f_pwd").value.trim();
    
   if (js_us.length == 0){
        //alert("ERROR:El usuario no puede ir vacío");
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: Olvidaste escribir tu usuario!',
        })
        return false;
    }

    else if (js_con.length==0){
        //alert("ERROR:La contraseña no puede ir vacía");
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: Olvidaste escribir tu contraseña!',
        })
        return false;
    }

    else if (js_con.length<6 || js_con.length>12){
        //alert("ERROR:la contraseña debe tener entre 6 y 12 characteres");
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'ERROR: La contraseña debe tener entre 6 y 12 characteres',
        })
        return false;
    }
    
}


function valida_sesion(){
    var js_us=document.getElementById("f_us").value.trim();
}