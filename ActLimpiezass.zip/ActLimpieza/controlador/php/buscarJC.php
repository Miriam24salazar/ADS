<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
</html>
<?php
    include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_actividad_dal.php");

    $id=$_GET("idAct");
    $nombre=$_GET("nombre");
    
    $actividad_ref=new actividad_dal;

    $existe=$actividad_ref->existe_actividad_id($id);
    if($existe==1){
        $actividad_ref=new actividad_dal;
        $actividad=$actividad_ref->datos_por_actividad($id);
        $array = array();
      array_push($array,$actividad);
      header('Content-type: application/json');
        echo json_encode($array);
    }
    else{
        $array=array();
        echo json_encode($array);
    }
?>