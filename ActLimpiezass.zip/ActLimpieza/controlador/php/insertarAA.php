<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
</html>

<?php
    include("C:/xampp/htdocs/ActLimpieza/modelo/class/class_actividad_dal.php");
    $actividad_ref=new actividad_dal;
    
    $idact=$_POST["f_idact"];
    $nombre=$_POST["f_nom"];
    $cuad=$_POST["cuad"];
    $col=$_POST["col"];
    $des=$_POST["f_des"];
    $img=$_POST["f_imag"];
    $estado=$_POST["f_estado"];
    
    $actividad = new actividad($idact, $cuad, $col, $nombre, $des, $estado, $img);
    $agregar=$actividad_ref->insertar_actividad($actividad);
    if($agregar==1){
        echo "Registro hecho correctamente";
    }
    else{
        echo "No se pudo registrar";
    }
?>