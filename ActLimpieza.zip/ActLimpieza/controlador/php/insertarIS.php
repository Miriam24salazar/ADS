<!DOCTYPE html>
<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
</html>

<?php
    include("../class/class_cuenta_dal.php");
    $cuenta_ref=new cuenta_dal;
    
    $us=strtoupper($_POST["f_us"]);
    $con=$_POST["f_pwd"];
    $id_cuen="SELECT id_cuenta FROM cuenta WHERE usuario='$us'";

    $obj_cuenta= new cuenta($id_cuen, $us, $con, null);
    
    //VALIDAR SI EXISTE
    $existe=$cuenta_ref->existe_cuenta($id_cuen);
    if ($existe==1){     

        /*
        $sql= "SELECT id_cuenta FROM `cuenta` WHERE usuario = '$us'";
        
        //buscar el tipo de usuario
        
        if($us=='admin'){
            $admin=$cuenta_ref->existe_cuenta($id_cuen==1)
        }
        
        $comparar = $cuenta_ref->datos_por_usuario($id_cuenta);
        $sql2= "SELECT U.tipoUsuario
            FROM usuarios U
            INNER JOIN cuenta CU ON U.id_cuenta = CU.id_cuenta_usuarios
            WHERE CU.id_cuenta = id_cuenta";
        
        include('../class/class_usuarios_dal.php');
        $obj_usuarios= new usuarios_dal;
        
        if($_POST['$us'] == 'admin' && $_POST['$con'] == '$con') {
            session_start();
            $_SESSION['admin'] = verdadero;
            header('Location: admin.php');
            salida;
            }
        
        */
    
        //insert     
        if ($candidatos_ref->insertar_candidato($obj_candidato)==1){

            if ($_FILES['f_curri']['name'] != null) {
                if(move_uploaded_file($tmp,$path)){
                    //echo 'Curriculum cargado';  
                    
                }
                else{
                    print "Error: Algo inesperado ocurrio al mover el archivo 1 a la trayectoria física, vuelva a intentar";
                }
            }
            //echo "<script>";
            // echo "alert('Candidato registrado con éxito');";
            //echo "<script>";
            //echo "Candidato Registrado";
            print '<script>';
                            print 'Swal.fire({
                            title: "Registro De Candidatos",
                            text: "¡Candidato Ingresado Correctamente!",
                            icon: "success"
                            }).then(function() {
                                window.location = "../index.php";
                            });';
                            print '</script>';
        }
        else{
            echo "No se logró ingresar al candidato";
        }
    //end insert
    }
else{
    echo "El candidato ya esta registrado";
}
?>