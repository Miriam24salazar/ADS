<!DOCTYPE html>
<html>
    <head>
        <meta charset='utf-8'>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Inicio de Sesión</title>
        <meta name="description" content="">
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <link rel='stylesheet' type='text/css' media='screen' href='css/estiloIS.css'>
        <script src='../controlador/validation/validationIS.js'></script>
    </head>
    <body>
        <div id="container"><!-- Inicio de Sesión -->
            <form name="forma" enctype="multipart/form-data" action="php/insertarIS.php" method="post" onsubmit="return valida_inicio();">
                
                <h1>INICIO DE SESIÓN</h1>
                
                <div id="row">
                    <label for="usuario">Usuario:</label>
                    <input type="text" id="f_us" name="f_us" placeholder="Escriba nombre">
                </div>

                <div id="row">
                    <label for="contra">Contraseña:</label>
                    <input type="password" id="f_pwd" name="f_pwd" placeholder="Escriba una contraseña">
                </div>

                <div id="row">
                    <input type="submit" value="Ingresar">
                </div>
                
            </form>
        </div><!-- end Inicio de Sesion -->

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        
    </body>
</html>