<?php
if (class_exists("cuenta")!=true){
    class cuenta{
        protected $id_cuenta;
        protected $usuario;
        protected $contrasena;

        public function __construct(
            $id_cuenta=NULL,
            $usuario=NULL,
            $contrasena=NULL) {
                $this->id_cuenta=$id_cuenta;
                $this->usuario=$usuario;
                $this->contrasena=$contrasena;
        }
        
        public function getId_Cuenta() {
                return $this->id_cuenta;
        }

        public function setId_Cuenta($id_cuenta) {
                $this->id_cuenta = $id_cuenta;
                return $this;
        }

        public function getUsuario() {
                return $this->usuario;
        }

        public function setUsuario($usuario) {
                $this->usuario = $usuario;
                return $this;
        }

        public function getContrasena() {
                return $this->contrasena;
        }

        public function setContrasena($contrasena) {
                $this->contrasena = $contrasena;
                return $this;
        }

    }//class

}//if exists
?>