<?php
    include('class_db.php');
    $obj_conn= new class_db();

    echo '<pre>';
    echo print_r($obj_conn);
    echo '</pre>';
?>  