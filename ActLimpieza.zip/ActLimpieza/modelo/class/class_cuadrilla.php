<?php
if (class_exists("cuadrilla")!=true){
    class cuadrilla{
        protected $id_cuadrilla;
        protected $nombre;

        public function __construct(
            $id_cuadrilla=NULL,
            $nombre=NULL) {
                $this->id_cuadrilla=$id_cuadrilla;
                $this->nombre=$nombre;
        }
        
        public function getId_Cuadrilla() {
                return $this->id_cuadrilla;
        }

        public function setId_Cuadrilla($id_cuadrilla) {
                $this->id_cuadrilla = $id_cuadrilla;
                return $this;
        }

        public function getNombre() {
                return $this->nombre;
        }

        public function setNombre($nombre) {
                $this->nombre = $nombre;
                return $this;
        }

    }//class

}//if exists
?>