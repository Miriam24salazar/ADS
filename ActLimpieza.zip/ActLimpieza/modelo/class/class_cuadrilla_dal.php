<?php
    include("class_cuadrilla.php");
    include("class_db.php");

    class cuadrilla_dal extends class_db{
        function __construct(){
            parent::__construct();
        }

        function __destruct(){
            parent::__destruct();
        }

        public function datos_por_nombre($nombre){
            $nombre=$this->db_conn->real_escape_string($nombre);
            $sql="SELECT * FROM cuadrilla WHERE nombre= $nombre";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_nombre=mysqli_num_rows($result);
            $obj_det=null;
            if($total_nombre==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new cuadrilla(
                    $renglon["id_cuadrilla"],
                    $renglon["nombre"]);
            }

            return $obj_det;
        }

        public function datos_por_id_cuadrilla($id_cuadrilla){
            $id_cuadrilla=$this->db_conn->real_escape_string($id_cuadrilla);
            $sql="SELECT * FROM cuadrilla WHERE id_cuadrilla= $id_cuadrilla";
            $this->set_sql($sql);
            $result=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $total_id_cuadrilla=mysqli_num_rows($result);
            $obj_det=null;
            if($total_id_cuadrilla==1){
                $renglon=mysqli_fetch_assoc($result);
                $obj_det= new cuadrilla(
                    $renglon["id_cuadrilla"],
                    $renglon["nombre"]);
            }

            return $obj_det;
        }

        function existe_cuadrilla($id_cuadrilla){
            $id_cuadrilla=$this->db_conn->real_escape_string($id_cuadrilla);
            $sql = "SELECT count(*) FROM cuadrilla";
            $sql.=" WHERE id_cuadrilla = $id_cuadrilla";

            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }
        
        function buscar_nombre($obj){
            $sql = "SELECT nombre FROM cuadrilla";
            $sql .= " WHERE id_cuadrilla = ".$obj->getId_Cuadrilla();
            
            $this->set_sql($sql);
            $rs=mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));

            $renglon=mysqli_fetch_array($rs);
            $cuantos=$renglon[0];

            return $cuantos;    
        }

        function insertar_cuadrilla($obj){
            
            $sql="INSERT INTO cuadrilla(";
            $sql.="id_cuadrilla,";
            $sql.="nombre )";            
            $sql.=" VALUES (";
            $sql.=$obj->getId_Cuadrilla().",";    
            $sql.="'".$obj->getNombre()."'";
            $sql.=")";

            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $insertado=1;
                }
                else{
                    $insertado=0;
                }
                unset($obj);
            return $insertado;
        }//end function        

        function borra_cuadrilla($id_cuadrilla){
            $id_cuadrilla=$this->db_conn->real_escape_string($id_cuadrilla);
            $sql="DELETE FROM cuadrilla WHERE id_cuadrilla= $id_cuadrilla";
            //echo $sql;return;
            $this->set_sql($sql);
            mysqli_query($this->db_conn,$this->db_query) 
            or die (mysqli_error($this->db_conn));
                if(mysqli_affected_rows($this->db_conn)==1){
                    $borrado=1;
                }
                else{
                    $borrado=0;
                }

                unset($obj);
                return $borrado;
        }

        function actualiza_cuadrilla($obj){
            /*
                    echo '<pre>';
                    echo print_r($obj);
                    echo '</pre>';
                    exit;
            */
            $sql = "UPDATE cuadrilla SET ";
            $sql .= "nombre="."'".$obj->Nombre()."'";
            $sql .= " WHERE id_cuadrilla = ".$obj->getId_Cuadrilla();
            
            //echo $sql;//exit;
            
            $this->set_sql($sql);
            $this->db_conn->set_charset("utf8");
            
            mysqli_query($this->db_conn,$this->db_query) 
            or die(mysqli_error($this->db_conn));
                
                if(mysqli_affected_rows($this->db_conn)==1) {
                    $actualizado=1;
                }            
                else{
                    $actualizado=0;
                }
            unset($obj);
            return $actualizado;
        }
        
    }//end class
?>